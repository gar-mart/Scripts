---========= TIMED OUT PROCS WITHIN LAST 5 DAYS FOR ALL DBs ===========

exec sys.sp_MSforeachdb '
use ?
declare @t table(
  db sysname,
  query_id int,
  object_id int,
  max_duration_ms bigint,
  set_options int,
  name sysname,
  total_duration_ms bigint,
  query_sql_text nvarchar(max),
  execution_type tinyint
)

;with cte as (
SELECT
  q.query_id,
  q.object_id,
  rs.max_duration/1000 max_duration_ms,
  rs.avg_duration * rs.count_executions /1000 total_duration_ms,
  cs.set_options,
  s.name + ''.'' + o.name name,
  qt.query_sql_text,
  qi.start_time,
  rs.execution_type
FROM sys.query_store_plan qp
INNER JOIN sys.query_store_query q
  ON qp.query_id = q.query_id
INNER JOIN sys.query_store_query_text qt
  ON q.query_text_id = qt.query_text_id
INNER JOIN sys.query_store_runtime_stats rs
  ON qp.plan_id = rs.plan_id
INNER JOIN sys.query_store_runtime_stats_interval qi
  ON rs.runtime_stats_interval_id = qi.runtime_stats_interval_id
LEFT JOIN sys.objects O 
  ON q.object_id = o.object_id
LEFT JOIN sys.schemas S
  ON O.schema_id = S.schema_id
INNER JOIN sys.query_context_settings cs
  ON q.context_settings_id = cs.context_settings_id
where qi.start_time >= dateadd(hour, 5 * (-24), cast(cast(getdate() as date) as datetime))
   and o.name is not null
   and rs.execution_type > 0
)
insert into @t(
  db,
  query_id,
  object_id,
  max_duration_ms,
  set_options,
  name,
  total_duration_ms,
  query_sql_text,
  execution_type
 )
SELECT
  db_name() db,
  query_id,
  object_id,
  max(max_duration_ms) max_duration_ms, 
  set_options,
  name,
  max(total_duration_ms) total_duration_ms,
  query_sql_text,
  execution_type
FROM cte
group by
  query_id,
  object_id,
  set_options,
  name,
  query_sql_text,
  execution_type

if exists(select * from @t)
select
  db,
  execution_type extype,
  query_id,
  object_id,
  max_duration_ms,
  set_options,
  name,
  total_duration_ms,
  query_sql_text
from @t
ORDER BY max_duration_ms DESC
'


--=====================================================


-- > 10 sec in the last 5 days

exec sys.sp_MSforeachdb '
use ?
declare @t table(
  db sysname,
  query_id int,
  object_id int,
  max_duration_ms bigint,
  set_options int,
  name sysname,
  total_duration_ms bigint,
  query_sql_text nvarchar(max),
  execution_type tinyint
)

;with cte as (
SELECT
  q.query_id,
  q.object_id,
  rs.max_duration/1000 max_duration_ms,
  rs.avg_duration * rs.count_executions /1000 total_duration_ms,
  cs.set_options,
  s.name + ''.'' + o.name name,
  qt.query_sql_text,
  qi.start_time,
  rs.execution_type
FROM sys.query_store_plan qp
INNER JOIN sys.query_store_query q
  ON qp.query_id = q.query_id
INNER JOIN sys.query_store_query_text qt
  ON q.query_text_id = qt.query_text_id
INNER JOIN sys.query_store_runtime_stats rs
  ON qp.plan_id = rs.plan_id
INNER JOIN sys.query_store_runtime_stats_interval qi
  ON rs.runtime_stats_interval_id = qi.runtime_stats_interval_id
LEFT JOIN sys.objects O 
  ON q.object_id = o.object_id
LEFT JOIN sys.schemas S
  ON O.schema_id = S.schema_id
INNER JOIN sys.query_context_settings cs
  ON q.context_settings_id = cs.context_settings_id
where qi.start_time >= dateadd(hour, 5 * (-24), cast(cast(getdate() as date) as datetime))
   and o.name is not null
)
insert into @t(
  db,
  query_id,
  object_id,
  max_duration_ms,
  set_options,
  name,
  total_duration_ms,
  query_sql_text,
  execution_type
 )
SELECT
  db_name() db,
  query_id,
  object_id,
  max(max_duration_ms) max_duration_ms, 
  set_options,
  name,
  max(total_duration_ms) total_duration_ms,
  query_sql_text,
  execution_type
FROM cte
group by
  query_id,
  object_id,
  set_options,
  name,
  query_sql_text,
  execution_type
having max(max_duration_ms) > 10000 -- 10 sec

if exists(select * from @t)
select
  db,
  execution_type extype,
  query_id,
  object_id,
  max_duration_ms,
  set_options,
  name,
  total_duration_ms,
  query_sql_text
from @t
ORDER BY max_duration_ms DESC
'


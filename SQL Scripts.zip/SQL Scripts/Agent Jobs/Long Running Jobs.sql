CREATE PROCEDURE [dbo].[DetectLongRunningJobs](
	@deviationTimes INT = 3
	, @defaultMaxDurationMinutes INT = 15
)
AS
SET NOCOUNT ON

IF OBJECT_ID('dbo.JobMaxDurationSetting') IS NULL BEGIN

	CREATE TABLE dbo.JobMaxDurationSetting(
		JobName SYSNAME NOT NULL
		, MaxDurationMinutes INT NOT NULL
	)

END

DECLARE
	@StartExecCount INT = 5  
	, @from_address VARCHAR(MAX) = '<Specify From Address Here>'
	, @subject VARCHAR(255) = 'Long Running Job Detected On ' + HOST_NAME()
	, @recipients VARCHAR(MAX) = '<Specify Recipient List>'
	, @body VARCHAR(MAX)
 
DECLARE @RunningJobs TABLE (
	job_id UNIQUEIDENTIFIER NOT NULL
	, last_run_date INT NOT NULL
	, last_run_time INT NOT NULL
	, next_run_date INT NOT NULL
	, next_run_time INT NOT NULL
	, next_run_schedule_id INT NOT NULL
	, requested_to_run INT NOT NULL
	, request_source INT NOT NULL
	, request_source_id SYSNAME NULL
	, running INT NOT NULL
	, current_step INT NOT NULL
	, current_retry_attempt INT NOT NULL
	, job_state INT NOT NULL
) 

DECLARE @DetectedJobs TABLE(
	JobId UNIQUEIDENTIFIER
	, JobName SYSNAME
	, ExecutionDate DATETIME
	, AvgDuration INT
	, MaxDuration INT
	, CurrentDuration INT
)

INSERT INTO @RunningJobs
EXEC master.dbo.xp_sqlagent_enum_jobs 1,''

;WITH JobsHistory AS (
	SELECT
		job_id
		, dbo.agent_datetime(run_date, run_time) DateExecuted
		, run_duration / 10000 * 3600 + run_duration % 10000 / 100*60 + run_duration % 100 Duration
	FROM dbo.sysjobhistory
	WHERE
		step_id = 0
		AND run_status = 1
)
, JobHistoryStats AS (
	SELECT
		job_id
		, AVG(Duration * 1.0) AvgDuration
		, AVG(Duration * 1.0) * @deviationTimes MaxDuration
	FROM JobsHistory
	GROUP BY job_id
	HAVING COUNT(*) >= @StartExecCount
)
INSERT INTO @DetectedJobs(
	JobId
	, JobName
	, ExecutionDate
	, AvgDuration
	, MaxDuration
	, CurrentDuration
)
SELECT
	a.job_id JobId
	, c.name JobName
	, MAX(e.start_execution_date) ExecutionDate
	, b.AvgDuration
	, ISNULL(MAX(i.MaxDurationMinutes) * 60, b.MaxDuration)
	, MAX(DATEDIFF(SECOND, e.start_execution_date, GETDATE())) CurrentDuration
FROM JobsHistory a
INNER JOIN JobHistoryStats b on a.job_id = b.job_id
INNER JOIN dbo.sysjobs c on a.job_id = c.job_id
INNER JOIN @RunningJobs d ON d.job_id = a.job_id
INNER JOIN dbo.sysjobactivity e ON e.job_id = a.job_id AND e.stop_execution_date IS NULL AND e.start_execution_date IS NOT NULL  -- run_requested_date IS NOT NULL
INNER JOIN dbo.sysjobs_view f ON f.job_id = e.job_id
INNER JOIN dbo.syssessions g ON g.session_id = e.session_id
INNER JOIN (SELECT MAX(agent_start_date) max_agent_start_date FROM dbo.syssessions) h ON g.agent_start_date = h.max_agent_start_date
LEFT JOIN dbo.JobMaxDurationSetting i ON i.JobName = c.name
WHERE
	DATEDIFF(SECOND, e.start_execution_date, GETDATE()) > ISNULL(i.MaxDurationMinutes * 60, (SELECT MAX(d) FROM (VALUES(b.MaxDuration), (@defaultMaxDurationMinutes * 60)) V(d)))
	AND d.job_state = 1
GROUP BY
	a.job_id
	, c.name
	, b.AvgDuration
	, b.MaxDuration

IF @@ROWCOUNT = 0 RETURN

DECLARE 
	@JobId UNIQUEIDENTIFIER
	, @JobName SYSNAME
	, @ExecutionDate DATETIME
	, @AvgDuration INT
	, @MaxDuration INT
	, @CurrentDuration INT

DECLARE JOBCURSOR CURSOR LOCAL FAST_FORWARD FOR 
SELECT JobId, JobName, ExecutionDate, AvgDuration, MaxDuration, CurrentDuration
FROM @DetectedJobs
ORDER BY CurrentDuration DESC

OPEN JOBCURSOR

FETCH NEXT FROM JOBCURSOR INTO @JobId, @JobName, @ExecutionDate, @AvgDuration, @MaxDuration, @CurrentDuration
SET @body = 'Long Running Jobs Detected On Server ' + CAST(HOST_NAME() AS VARCHAR(128)) + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10)

WHILE @@FETCH_STATUS = 0 BEGIN

	SET @body += 'Job Name: ' + CAST(@JobName AS VARCHAR(128)) + '  (ID: ' + CAST(@JobId AS CHAR(36)) + ')' + CHAR(13) + CHAR(10)
	SET @body += 'StartDate: ' + CAST(@ExecutionDate AS VARCHAR(25)) + CHAR(13) + CHAR(10)
	SET @body += 'Current Duration: ' + CAST(@CurrentDuration / 3600 AS VARCHAR(10)) + ':' + RIGHT('00' + CAST(@CurrentDuration % 3600 / 60 AS VARCHAR(2)), 2) + ':' + RIGHT('00' + CAST(@CurrentDuration % 60 AS VARCHAR(2)), 2) + CHAR(13) + CHAR(10)
	SET @body += 'Average Duration: ' + CAST(@AvgDuration / 3600 AS VARCHAR(10)) + ':' + RIGHT('00' + CAST(@AvgDuration % 3600 / 60 AS VARCHAR(2)), 2) + ':' + RIGHT('00' + CAST(@AvgDuration % 60 AS VARCHAR(2)), 2) + CHAR(13) + CHAR(10)
	SET @body += 'Max Duration: ' + CAST(@MaxDuration / 3600 AS VARCHAR(10)) + ':' + RIGHT('00' + CAST(@MaxDuration % 3600 / 60 AS VARCHAR(2)), 2) + ':' + RIGHT('00' + CAST(@MaxDuration % 60 AS VARCHAR(2)), 2) + CHAR(13) + CHAR(10)
	SET @body += CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10)

	FETCH NEXT FROM JOBCURSOR INTO @JobId, @JobName, @ExecutionDate, @AvgDuration, @MaxDuration, @CurrentDuration

END

CLOSE JOBCURSOR
DEALLOCATE JOBCURSOR

EXEC dbo.sp_send_dbmail
	@from_address = @from_address
	, @recipients = @recipients
	, @subject = @subject
	, @body = @body



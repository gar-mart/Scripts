--- Jobs Sorted by Execution Start Time

select j.name, j.description, a.start_execution_date
from msdb.dbo.sysjobs j
inner join msdb.dbo.sysjobactivity a on j.job_id = a.job_id
where a.start_execution_date > cast(getdate() as date)
and j.enabled = 1
order by start_execution_date


--------------------------

--- Jobs with their owners
select a.name Job_Name, b.name Job_Owner
from msdb.dbo.sysjobs_view a
left join master.dbo.syslogins b on a.owner_sid = b.sid


--------------------------------------


-- Failed Agent jobs:
select j.name
    ,js.step_name
    ,jh.sql_severity
    ,jh.message
    ,jh.run_date
    ,jh.run_time
from msdb.dbo.sysjobs as j
inner join msdb.dbo.sysjobsteps as js on js.job_id = j.job_id
inner join msdb.dbo.sysjobhistory as jh on jh.job_id = j.job_id 
where jh.run_status = 0

----------------


-- Job with specific STEP name:
select j.name
    ,js.step_name
    ,jh.sql_severity
    ,jh.message
    ,jh.run_date
    ,jh.run_time
from msdb.dbo.sysjobs as j
inner join msdb.dbo.sysjobsteps as js on js.job_id = j.job_id
inner join msdb.dbo.sysjobhistory as jh on jh.job_id = j.job_id 
where js.step_name = 'TransactionReCalc'
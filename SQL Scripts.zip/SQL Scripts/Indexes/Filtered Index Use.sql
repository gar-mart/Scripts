-- Help to determine where filtered indexes can be useful

select 
	'select ''' +
		c.name + '.' + b.name  + ''' TableName, '''
		+ a.name + ''' ColumnName ' + '
		, (select count(*) from ' + c.name + '.' + b.name + ' with(nolock)) OverallCount  
		, (select count(*) from ' + c.name + '.' + b.name + ' with(nolock) where ' + a.name + ' = 1) ActiveCount ' 
from sys.columns a
inner join sys.objects b on a.object_id = b.object_id
inner join sys.schemas c on b.schema_id = c.schema_id
where a.name like '%Active' and b.type = 'U' and c.name <> 'Temporal'




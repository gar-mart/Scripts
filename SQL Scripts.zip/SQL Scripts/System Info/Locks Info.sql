create procedure Locks_Info
as set nocount on
begin
	drop table if exists #lockInfo  
	drop table if exists #processInfo

    create table #lockInfo(
		lock_id int identity,
		session_id int,
		resource_type nvarchar(255),
		resource_associated_entity_id bigint,
		request_mode nvarchar(60),
		request_status nvarchar(60),
		resource_description nvarchar(max)
	)
    create table #processInfo(
		session_id int, 
		status nvarchar(255), 
		login_name nvarchar(255), 
		host_name nvarchar(255), 
		blocked_by nvarchar(255), 
		db_name nvarchar(255), 
		command nvarchar(max)
	)

    insert into #lockInfo
    select t1.request_session_id as session_id, t1.resource_type, t1.resource_associated_entity_id, t1.request_mode, t1.request_status, t2.object_id
    from sys.dm_tran_locks t1
    join sys.partitions t2 on t1.resource_associated_entity_id = t2.hobt_id
    where t1.resource_database_id = db_id()

    insert into #processInfo
    select s.session_id, s.status, s.login_name, s.host_name, r.blocking_session_id, db_name(s.database_id) as db_name, r.command
    from sys.dm_exec_sessions s
    left join sys.dm_exec_requests r on s.session_id = r.session_id

    select l.session_id, p.status, p.login_name, p.host_name, l.request_mode, l.request_status, w.wait_duration_ms as lock_wait_time
    from #lockInfo l
    join #processInfo p on l.session_id = p.session_id
    join sys.dm_os_waiting_tasks w on p.session_id = w.session_id
    where w.wait_type like '%LCK%'

    select resource_type, request_mode, count(*) as lock_count
    from #lockInfo
    group by resource_type, request_mode

    drop table #lockInfo
    drop table #processInfo
end

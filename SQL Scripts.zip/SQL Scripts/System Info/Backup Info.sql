CREATE PROCEDURE GetBackupInfo
AS
BEGIN
    -- Report 1: Non-Simple DBs without Log Backups
    SELECT 
        D.name AS DatabaseName, 
        D.recovery_model_desc AS RecoveryModelDescription
    FROM sys.databases D
    LEFT JOIN  
    ( 
        SELECT 
            BS.database_name,  
            MAX(BS.backup_finish_date) AS LastLogBackupDate
        FROM msdb.dbo.backupset BS  
        WHERE BS.type = 'L' 
        GROUP BY BS.database_name 
    ) AS LastLogBackup ON D.name = LastLogBackup.database_name 
    WHERE D.recovery_model_desc != 'SIMPLE' 
        AND LastLogBackup.LastLogBackupDate IS NULL 
    ORDER BY D.name;

    -- Report 2: Last Log Backup Time for All Databases
    SELECT 
        sysdatabases.name AS DatabaseName,
        MAX(backupset.backup_finish_date) AS LastLogBackupFinishDate
    FROM master.sys.sysdatabases
    LEFT OUTER JOIN msdb.dbo.backupset ON backupset.database_name = sysdatabases.name 
        AND backupset.type = 'L'
    GROUP BY sysdatabases.name
    ORDER BY LastLogBackupFinishDate DESC;

    -- Report 3: Last Backup Time for All Databases
    SELECT 
        sysdatabases.Name AS DatabaseName,
        COALESCE(CONVERT(VARCHAR(12), MAX(backupset.backup_finish_date), 101), '-') AS LastBackupTime
    FROM sys.sysdatabases
    LEFT OUTER JOIN msdb.dbo.backupset ON backupset.database_name = sysdatabases.name
    GROUP BY sysdatabases.Name;
END
